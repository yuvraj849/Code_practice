package com.mii.oopsconcept;
/*
public class StaticVariableCounter {
	
	static int count=0;
	StaticVariableCounter(){
		count++;
		System.out.println(count);
	}
public static void main (String[] args) {
	StaticVariableCounter S = new StaticVariableCounter();
	StaticVariableCounter S1 = new StaticVariableCounter();
	StaticVariableCounter S2 = new StaticVariableCounter();


}
}

OUTPUT
1
2
3
*/

//WITHOUT STATIC VARIABLE
/*
public class StaticVariableCounter {
	
	 int count=0;
	StaticVariableCounter(){
		count++;
		System.out.println(count);
	}
public static void main (String[] args) {
	StaticVariableCounter S = new StaticVariableCounter();
	StaticVariableCounter S1 = new StaticVariableCounter();
	StaticVariableCounter S2 = new StaticVariableCounter();


}
}

OUTPUT
1
1
1*/
