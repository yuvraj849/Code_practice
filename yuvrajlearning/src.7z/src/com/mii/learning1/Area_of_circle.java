/*package com.mii.learning1;

import java.io.IOException;*/

// pie rsquare

/*
class operation{
	int square(int n) {
		return n*n;
	}
	
}


public class Area_of_circle {
	double pie=3.14;
	operation op;
	double area(int radius) {
		op= new operation();
		int rsquare=op.square(radius);
		return pie*rsquare;
	}
	public static void main(String[] args) {
		Area_of_circle c = new Area_of_circle();
		double result = c.area(5);
		System.out.println(result);
	}

}*/
/*
class operation{
	double pie=3.14;
	double square(int n) {
		return n*n*pie;
	}
	
}
public class Area_of_circle{
	public static void main(String[] args) {
		operation op = new operation();
		double result = op.square(5);
		
		System.out.println(result);
	}
	
}
*//*
public class Area_of_circle{
	public static void main(String[] args) {

		//System.err.println("error printed");
		int i;
		try {
			i = System.in.read();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//returns ASCII code of 1st character  
		System.out.println((char)i);//will print the character  
	}
	
}*/
