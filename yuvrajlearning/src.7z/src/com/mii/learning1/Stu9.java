package com.mii.learning1;

public class Stu9 {
	public int a=10;
  
}
