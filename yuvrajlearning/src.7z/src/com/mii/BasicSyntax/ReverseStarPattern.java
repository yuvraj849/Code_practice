package com.mii.BasicSyntax;

public class ReverseStarPattern {

	public static void main(String[] args) {
		for(int i=5;i>=1;i--){  
		for(int j=i;j>=1;j--){  
		        System.out.print("* ");  
		}  //end of i
		System.out.println(" ");//new line  
		}  //end j
		 
	}

}
