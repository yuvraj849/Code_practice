package com.mii.BasicSyntax;

public class AllSyntax {

}
